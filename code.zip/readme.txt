Group ID:   14
Developer:  HSU, Li-hsiu
Student ID: 20895023
Email:      Lhsuaa@connect.ust.hk

Recommend to run the website with google chrome to avoid lagging.
Run the code by starting a local host and run index.html OR For simplicity, can just use the below website.
Github Page: https://li-hsiu.github.io/peck-thrive/

Github Repository: https://github.com/Li-Hsiu/peck-thrive

Tutorial: 
(1) Press "Start Game" after progress bar is complete.
(2) Click SPACE to start flying.
(3) Use WASD to control the woodpecker.
(4) Bump into noise indicators or nests to interact.